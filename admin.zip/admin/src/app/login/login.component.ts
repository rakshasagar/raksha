import { Component, AfterViewInit, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Service } from '../service';
import { CookieService } from 'angular2-cookie/core';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements AfterViewInit, OnInit {

  ngAfterViewInit() { }
  private _sessionId: string;
  Host: String;
  user: any;
  profileForm: any;

  constructor(private route: ActivatedRoute, public router: Router, public http: HttpClient, public service: Service, private cookieService: CookieService) {
    this.profileForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)

    });
    this.Host = this.service.host();
    // this._sessionId = cookieService.get("sessionId");
  }


  login() {
    let formData = this.profileForm.value;
    var params = {
      username: formData.username,
      password: formData.password
    }
    console.log(params)
    this.http.get(this.Host + "/users").pipe().subscribe(val => {
      console.log(val, "login service");
      if (val[0].username == params.username && val[0].password == params.password) {
        localStorage.setItem("IsLoggedIn", params.username);

        //  this._cookieService.put('nameOfCookie',params.username)
        this.router.navigate(["admin"])

      }
      else
        alert("invalid password");

    },
    )
  }

  ngOnInit() {
  }
}