import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
@Component({
  selector: 'admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnDestroy {
  profileForm: any;
  private fieldArray: Array<any> = [];
  private newAttribute: any = {};

  constructor(public router: Router) {
    this.profileForm = new FormGroup({
      SourceIp: new FormControl('', Validators.required),
      DestinationIp: new FormControl('', Validators.required)

    });
  }



  ngOnDestroy() {
    localStorage.removeItem('IsLoggedIn');

  }
  logout() {
    this.ngOnDestroy;
    this.router.navigate(["login"])
  }

}