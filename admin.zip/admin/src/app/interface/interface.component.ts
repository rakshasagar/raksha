import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-interface',
  templateUrl: './interface.component.html',
  styleUrls: ['./interface.component.css'],
})
export class InterfaceComponent implements OnInit {
  private fieldArray: Array<any> = [];
  private newAttribute: any = {};
  value: any = '';

  constructor() { }

  addRow() {
    this.fieldArray.push(this.newAttribute)
    this.newAttribute = {};
  }

  deleteRow(index) {
    this.fieldArray.splice(index, 1);
  }
  applyFilter(filterValue: any) {
    return this.fieldArray.filter = filterValue.trim().toLowerCase();
    console.log(this.fieldArray);
  }

  firstClick() {
    this.fieldArray;
    console.log(this.fieldArray);
  }

  previousClick() {
  }

  ngOnInit() {
  }

}
